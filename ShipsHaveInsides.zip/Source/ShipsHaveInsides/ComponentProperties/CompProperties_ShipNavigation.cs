﻿using Verse;

namespace RimWorld
{
    public class CompProperties_ShipNavigation : CompProperties
    {
        public CompProperties_ShipNavigation()
        {
            this.compClass = typeof(ShipNavigationComponent);
        }
    }
}
