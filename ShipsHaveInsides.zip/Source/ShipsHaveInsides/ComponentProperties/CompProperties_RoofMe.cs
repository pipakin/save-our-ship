﻿using Verse;

namespace RimWorld
{
  public class CompProperties_RoofMe : CompProperties
  {
    public CompProperties_RoofMe()
    {
      this.compClass = typeof (CompRoofMe);
    }
  }
}
